const express = require('express');
const route = express.Router();
const controllers = require('../controllers/adminController');
const passport = require('../middelware/authentication');
const upload = require('../middelware/adminMulter');

route.get('/login', controllers.loginPage);
route.post('/login', passport.authenticate('local', {
    successRedirect: '/dashboard',
    failureRedirect: '/login',
    failureFlash: false // if you use flash messages, set true
}));

// Password Reset routes
route.get('/lostPassword', passport.checkLostPasswordAuthentication, controllers.losspassword);
route.post('/checkEmail', controllers.checkEmail);
route.post('/checkOtp', controllers.checkOtp);
route.get('/newsetpassword', passport.checkLostPasswordAuthentication, controllers.newsetpassword);
route.post('/checknewpassword', controllers.checknewpassword);

// Password Change routes
route.get('/changePassword', passport.checkAuthentication, controllers.changePassword);
route.post('/changemypassword', passport.checkAuthentication, controllers.changemypassword);

// Dashboard
route.get('/dashboard', passport.checkAuthentication, controllers.DashbordPage);

// Admin management
route.get('/addAdmin', passport.checkAuthentication, controllers.addAdminPage);
route.get('/viewAdmin', passport.checkAuthentication, controllers.viewAdminPage);
route.get('/viewProfile', passport.checkAuthentication, controllers.viewProfile);
route.get('/updateProfile', passport.checkAuthentication, controllers.updateProfile);
route.post('/editProfile', passport.checkAuthentication, upload.single('avatar'), controllers.editProfile);

// CRUD
route.post('/insert', passport.checkAuthentication, upload.single('avatar'), controllers.insertAdmin);
route.get('/delete-addmin/:DeleteId', passport.checkAuthentication, controllers.DeleteAdmin);
route.get('/updateAdmin', passport.checkAuthentication, controllers.UpdateAdmin);
route.post('/editAdmin/:editId', passport.checkAuthentication, upload.single('avatar'), controllers.editAdmin);

module.exports = route;
