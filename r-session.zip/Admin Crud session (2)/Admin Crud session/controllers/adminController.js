const admin = require('../models/adminModel');
const nodemailer = require('nodemailer');
const fs = require('fs');

// Login Page
const loginPage = (req, res) => {
    res.render('login');
};

// Logout
const logout = (req, res) => {
    req.logout(err => {
        if (err) return res.send(`<h2>Error: ${err}</h2>`);
        req.session.destroy();
        res.redirect('/');
    });
};

// Password recovery - enter email
const losspassword = (req, res) => {
    res.render('losspassword');
};

// Check email and send OTP
const checkEmail = async (req, res) => {
    try {
        const email = req.body.email;
        const data = await admin.findOne({ email });

        if (data) {
            const transporter = nodemailer.createTransport({
                service: "gmail",
                auth: {
                    user: "rahulpatadiya07@gmail.com",
                    pass: "elyiecppuhrbpfnk",
                },
            });

            const otp = Math.floor(Math.random() * 900000 + 100000);
            const mail = {
                from: '"Admin Panel" <rahulpatadiya07@gmail.com>',
                to: email,
                subject: "OTP Verification - Password Recovery",
                html: `<h2>Your OTP is: ${otp}</h2>`,
            };

            await transporter.sendMail(mail);
            req.session.otp = otp;
            req.session.email = email;
            res.render('otppage');
        } else {
            res.redirect('/losspassword');
        }
    } catch (error) {
        res.send(`<h2>Error: ${error}</h2>`);
    }
};

// Verify OTP
const checkOtp = (req, res) => {
    if (req.body.otp == req.session.otp) {
        res.redirect('/newSetPassword');
    } else {
        res.redirect('/otppage');
    }
};

// Show new password form
const newsetpassword = (req, res) => {
    res.render('newSetPassword');
};

// Save new password
const checknewpassword = async (req, res) => {
    try {
        const { newPassword, confimPassword } = req.body;
        if (newPassword === confimPassword) {
            const email = req.session.email;
            const user = await admin.findOneAndUpdate({ email }, { password: newPassword });
            req.session.otp = null;
            req.session.email = null;
            res.redirect('/');
        } else {
            res.redirect('back');
        }
    } catch (error) {
        res.send(`<h2>Error: ${error}</h2>`);
    }
};

// Check login credentials (Passport handles session)
const userChecked = async (req, res) => {
    res.redirect('/dashbord');
};

// Change Password Page
const changePassword = (req, res) => {
    if (req.isAuthenticated()) {
        res.render('changepassword', { currentAdmin: req.user });
    } else {
        res.redirect('/login');
    }
};

// Handle Password Change
const changemypassword = async (req, res) => {
    const { oldpassword, newpassword, confimpassword } = req.body;
    const user = req.user;

    if (oldpassword === user.password) {
        if (newpassword !== user.password && newpassword === confimpassword) {
            await admin.findByIdAndUpdate(user._id, { password: newpassword });
            res.redirect('/login');
        } else {
            res.redirect('/changepassword');
        }
    } else {
        res.redirect('/changepassword');
    }
};

// View profile
const viewProfile = (req, res) => {
    if (req.isAuthenticated()) {
        res.render('profile', { currentAdmin: req.user });
    } else {
        res.redirect('/');
    }
};

// Update profile form
const updateProfile = (req, res) => {
    if (req.isAuthenticated()) {
        res.render('updateprofile', { currentAdmin: req.user });
    } else {
        res.redirect('/');
    }
};

// Edit profile
const editProfile = async (req, res) => {
    try {
        const updated = await admin.findByIdAndUpdate(req.user._id, req.body, { new: true });
        res.redirect('back');
    } catch (error) {
        res.send(`<h2>Error: ${error}</h2>`);
    }
};

// Dashboard
const DashbordPage = (req, res) => {
    if (!req.isAuthenticated()) return res.redirect('/');
    const loginSuccess = req.session.loginSuccess;
    req.session.loginSuccess = null;
    res.render('dashbord', { currentAdmin: req.user, loginSuccess });
};

// Add admin form
const addAdminPage = (req, res) => {
    if (!req.isAuthenticated()) return res.redirect('/');
    const adminSuccess = req.session.adminSuccess;
    req.session.adminSuccess = null;
    res.render('addAdmin', { currentAdmin: req.user, adminSuccess });
};

// View all admins
const viewAdminPage = async (req, res) => {
    if (!req.isAuthenticated()) return res.redirect('/');
    let records = await admin.find({});
    records = records.filter((data) => data.id != req.user._id);
    res.render('viewAdmins', { records, currentAdmin: req.user });
};

// Insert new admin
const insertAdmin = async (req, res) => {
    try {
        req.body.avatar = req.file.path;
        await admin.create(req.body);
        req.session.adminSuccess = true;
        res.redirect('/addAdmin');
    } catch (error) {
        res.send(`<h2>Error: ${error}</h2>`);
    }
};

// Delete admin
const DeleteAdmin = async (req, res) => {
    try {
        const data = await admin.findByIdAndDelete(req.params.DeleteId);
        if (data?.avatar) fs.unlinkSync(data.avatar);
        res.redirect('/viewAdmin');
    } catch (error) {
        res.send(`<h2>Error: ${error}</h2>`);
    }
};

// Update admin form
const UpdateAdmin = async (req, res) => {
    try {
        const data = await admin.findById(req.query.id);
        if (!data) return res.redirect('/viewAdmin');
        res.render('updateadmin', { data, currentAdmin: req.user });
    } catch (error) {
        res.send(`<h2>Error: ${error}</h2>`);
    }
};

// Handle update post
const editAdmin = async (req, res) => {
    try {
        const data = await admin.findById(req.params.editId);
        if (req.file) {
            if (data.avatar) fs.unlinkSync(data.avatar);
            req.body.avatar = req.file.path;
        } else {
            req.body.avatar = data.avatar;
        }
        await admin.findByIdAndUpdate(req.params.editId, req.body);
        res.redirect('/viewAdmin');
    } catch (error) {
        res.send(`<h2>Error: ${error}</h2>`);
    }
};

module.exports = {
    loginPage,
    logout,
    userChecked,
    losspassword,
    checkEmail,
    checkOtp,
    newsetpassword,
    checknewpassword,
    changePassword,
    changemypassword,
    viewProfile,
    updateProfile,
    editProfile,
    DashbordPage,
    addAdminPage,
    viewAdminPage,
    insertAdmin,
    DeleteAdmin,
    UpdateAdmin,
    editAdmin,
};
