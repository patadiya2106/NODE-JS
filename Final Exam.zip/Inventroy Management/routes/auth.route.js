const express =  require("express");

const route = express.Router();

const{register , login , authprofile}= require("../controllers/auth.controllers");

route.post("/register" ,register);

route.post("/login", login);

// FETCH ADMIN
route.patch("/authprofile", authprofile);


module.exports = route;