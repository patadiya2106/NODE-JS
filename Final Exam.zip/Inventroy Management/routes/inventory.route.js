const express =  require("express");

const route = express.Router();

module.exports = route;