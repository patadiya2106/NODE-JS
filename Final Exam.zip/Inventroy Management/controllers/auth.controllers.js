const auth = require("../models/auth.model");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

exports.register = async (req, res) => {
  try {
    if (await auth.findOne({ email: req.body.email })) {
      res
        .status(401)
        .json({ status: false, error: "Email is already exits.." });
    }

    req.body.password = await bcrypt.hash(req.body.password, 8);

    (await auth.create(req.body))
      ? res
          .status(201)
          .json({ status: true, message: "Auth is created successfully...." })
      : res
          .status(401)
          .json({ status: false, error: "Auth is not created...." });
  } catch (err) {
    console.log(err);
    res.status(400).json({
      status: false,
      error: "Something went wrong...",
      error_data: err,
    });
  }
};

exports.login = async (req, res) => {
  try {
    const currentAuth = await auth.findOne({ email: req.body.email });

    if (!currentAuth) {
      res.status(401).json({ status: false, error: "Admin is not found..." });
    }
    if(await bcrypt.compare(req.body.password, currentAuth.password))
      { 
       const token = jwt.sign({currentAuth}, process.env.SECRET_KEY,)
        
        res.status(201)
          .json({
            status: true,
            message: " Admin Login  successfully....",
            auth: currentAuth,
            auth_token: token,
          })
        }
      else
        res.status(401).json({ status: false, error: "Password is wrong..." });
  } catch (err) {
    console.log(err);
    res.status(400).json({
      status: false,
      error: "Something went wrong...",
      error_data: err,
    });
  }
};

exports.authprofile = async (req, res) => {
  try{
    const allAuth = await auth.find({});
    (allAuth)?
      res.status(200).json({ status: true, data: allAuth })  
      : res.status(200).json({ status: false, error: "Admin is not found..." });
  }catch(err) {
    console.log(err);
    res.status(400).json({
      status: false,
      error: "Something went wrong...",
      error_data: err,
    });
}
}